package com.blog.service;

import com.blog.model.Comment;

public interface CommentService {

    Comment save(Comment comment);
}
